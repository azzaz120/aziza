import React from 'react';
import { Player, ControlBar } from 'video-react';

const MyHLSPlayer = () => {
  return (
    <Player>
      <source src="https://adam.melset.com/live/sqZc4G_Yo/index.m3u8" type="application/x-mpegURL" />
      <ControlBar autoHide={false} />
    </Player>
  );
};

export default MyHLSPlayer;


import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Live from './Live';

const LiveList = () => {
  const [liveList, setLiveList] = useState([]);

  useEffect(() => {
    // Función para obtener la lista de transmisiones en vivo desde el backend
    const fetchLiveList = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/live');
        setLiveList(response.data); // Suponiendo que el servidor devuelve la lista de transmisiones en vivo en el formato correcto
      } catch (error) {
        console.error('Error al obtener la lista de transmisiones en vivo:', error);
      }
    };

    // Llamada a la función para obtener la lista cuando el componente se monta
    fetchLiveList();
  }, []);

  return (
    <div>
      <h2>Live List</h2>
      {liveList.map(liveData => (
        <Live key={liveData._id} liveId={liveData._id} />
      ))}
    </div>
  );
};

export default LiveList;


// AddProductForm.js
import React, { useState } from 'react';
import axios from 'axios';

const AddProductForm = ({ liveId, onProductAdded }) => {
  const [newProduct, setNewProduct] = useState({
    _id: '', // Puedes añadir más campos según tus necesidades
  });

  const handleInputChange = (e) => {
    setNewProduct({
      ...newProduct,
      [e.target.name]: e.target.value,
    });
  };

  const handleAddProduct = async (e) => {
    e.preventDefault();

    try {
      // Realizar la solicitud POST para agregar el producto
      const response = await axios.post(`/api/live/${liveId}/add`, { newProducts: [newProduct] });

      // Llamar a la función proporcionada para actualizar la interfaz de usuario con el nuevo producto
      if (response.data.success) {
        onProductAdded(response.data.live.products[0]);
      }
    } catch (error) {
      console.error('Error al agregar el producto:', error);
      // Manejar el error según sea necesario
    }
  };

  return (
    <form onSubmit={handleAddProduct}>
      <label>
        Nuevo Producto:
        <input type="text" name="_id" value={newProduct._id} onChange={handleInputChange} />
      </label>
      <button type="submit">Agregar Producto</button>
    </form>
  );
};

export default AddProductForm;


import React, { useState } from 'react';
import axios from 'axios';
import './Register.css';
import { useHistory } from 'react-router-dom';

const Register = () => {
  const [formData, setFormData] = useState({
    email: '',
    first_name: '',
    phone: '',
    password: '',
    city: '',
    user_type: '',
  });
     const history = useHistory();
  const [errorMessage, setErrorMessage] = useState('');
  const [authMessage, setAuthMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');



  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

const handleRegister = async () => {
  try {
    const response = await axios.post('http://localhost:5000/api/auth/register', formData);

    if (response.data.success) {
      setAuthMessage('Usuario registrado exitosamente.');
      setSuccessMessage(response.data.message);
      setErrorMessage('');

      // Muestra el mensaje de éxito y espera unos segundos antes de redirigir
      setTimeout(() => {
        setSuccessMessage('');
        // Redirige al usuario a la página de inicio de sesión
        history.push('/login');
      }, 3000); // Cambia el tiempo de espera según tus preferencias
    } else {
      setErrorMessage(response.data.message);
      setAuthMessage('');
      setSuccessMessage('');
    }
  } catch (error) {
    console.error('Error en el registro:', error.response?.data);

    if (error.response?.data?.message) {
      setErrorMessage(error.response.data.message);
    }
    if (error.response?.data?.authMessage) {
      setAuthMessage(error.response.data.authMessage);
    }
    setSuccessMessage('');
  }
};

  return (
    <div className="container">
      <h1>Registro</h1>

      {/* Mensajes de error, autenticación y éxito */}
      {errorMessage && <div className="error-message">{errorMessage}</div>}
      {authMessage && <div className="auth-message">{authMessage}</div>}
      {successMessage && <div className="success-message">{successMessage}</div>}

      {/* Campos de entrada para el registro */}
      <input
        type="email"
        name="email"
        placeholder="Correo electrónico"
        onChange={handleChange}
        value={formData.email}
      />
      <input
        type="text"
        name="first_name"
        placeholder="Nombre"
        onChange={handleChange}
        value={formData.first_name}
      />
      <input
        type="text"
        name="phone"
        placeholder="Número de teléfono"
        onChange={handleChange}
        value={formData.phone}
      />
      <input
        type="password"
        name="password"
        placeholder="Contraseña"
        onChange={handleChange}
        value={formData.password}
      />
      <input
        type="text"
        name="state"
        placeholder="Estado"
        onChange={handleChange}
        value={formData.state}
      />
      <input
        type="text"
        name="city"
        placeholder="Ciudad"
        onChange={handleChange}
        value={formData.city}
      />

      <select
        name="user_type"
        onChange={handleChange}
        value={formData.user_type}
      >
        <option value="">Selecciona tipo de usuario</option>
        <option value="admin">Admin</option>
        <option value="buyer">Buyer</option>
        <option value="vendor">Vendor</option>
      </select>

      <button onClick={handleRegister}>Registrarse</button>

      <div className="footer">
        <p>© 2024 Rez.im, Inc.</p>
      </div>
    </div>
  );
};

export default Register;


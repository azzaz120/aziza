import styles from "./TitleFrame.module.css";

const TitleFrame = () => {
  return (
    <div className={styles.titleFrame}>
      <div className={styles.conditionFrame}>
        <div className={styles.nestedFramesPair}>
          <div className={styles.cit}>{`city- `}</div>
          <div className={styles.city}>PPK55656</div>
        </div>
        <div className={styles.nestedFramesPair1}>
          <div className={styles.con}>Condition-</div>
          <div className={styles.condition}>
            <span>{` `}</span>
            <span className={styles.markouto}>Markouto</span>
          </div>
        </div>
      </div>
      <div className={styles.titleText}>
        <div className={styles.title}>
          AgriPro 3 HP Butterfly Combined Rice Mill Machine without Motor
          APCRM6N9FC
        </div>
      </div>
      <div className={styles.costText}>
        <div className={styles.checkmark}>
          <div className={styles.stockText}>
            <div className={styles.shipping}>shippingCost :</div>
            <div className={styles.shippingcost}>shippingCost</div>
          </div>
          <div className={styles.brandText}>
            <img
              className={styles.checkCircleOutlineIcon}
              loading="eager"
              alt=""
              src="/check-circle-outline.svg"
            />
            <div className={styles.buyNowFrame}>{`In stock `}</div>
          </div>
        </div>
      </div>
      <div className={styles.labelText}>
        <div className={styles.stockGroup}>
          <div className={styles.totalPriceFrame}>
            <div className={styles.stock}>Stock :</div>
            <div className={styles.rectangleParent}>
              <div className={styles.frameChild} />
              <div className={styles.stock1}>1</div>
            </div>
          </div>
          <div className={styles.brandTextPair}>
            <div className={styles.shippingCostLabel}>
              <div className={styles.addToCartBtn}>
                <div className={styles.rupeeSymbol}>
                  <div className={styles.div}>
                    <b>₹</b>
                    <span className={styles.span}>450</span>
                  </div>
                  <div className={styles.discountValue} />
                </div>
              </div>
              <div className={styles.finalPriceLabel}>
                <div className={styles.discount}>18% off</div>
              </div>
              <div className={styles.checkmarkIcon}>
                <b className={styles.b}>₹</b>
                <div className={styles.finalprice}>350</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TitleFrame;

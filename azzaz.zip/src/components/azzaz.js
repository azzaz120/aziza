// App.js
import React, { useState, useEffect } from 'react';
import CategoryMenu from './CategoryMenu';
import SearchBar from './SearchBar';
import FeaturedProducts from './FeaturedProducts';
import './App.css'; // Importa los estilos

const API_BASE_URL = 'http://localhost:5000/api';

function App() {
  const [categories, setCategories] = useState([]);
  const [featuredProducts, setFeaturedProducts] = useState([]);

  useEffect(() => {
    // Llamada a la API para obtener categorías
    fetch(`${API_BASE_URL}/category`)
      .then(response => response.json())
      .then(data => setCategories(data));

    // Llamada a la API para obtener productos destacados
    fetch(`${API_BASE_URL}/product`)
      .then(response => response.json())
      .then(data => setFeaturedProducts(data));
  }, []);

  return (
    <div className="app-container">
      <header>
        <img src="logo.png" alt="Logo de tu sitio" />
      </header>

      <div className="main-container">
        <div className="category-menu-container">
          <CategoryMenu categories={categories} />
        </div>

        <div className="search-bar-container">
          <SearchBar />
        </div>

        <div className="grid-container">
          <FeaturedProducts products={featuredProducts} />
        </div>
      </div>
    </div>
  );
}

export default App;




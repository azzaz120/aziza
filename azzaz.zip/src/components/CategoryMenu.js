// CategoryMenu.js
import React from 'react';
import './CategoryMenu.css'; // Importa los estilos

function CategoryMenu({ categories }) {
  // Verifica si categories es un array antes de usar map
  if (!Array.isArray(categories)) {
    // Si no es un array, muestra un mensaje de error o maneja la situación según tus necesidades
    return <div>Error: Categorías no válidas</div>;
  }

  return (
    <nav>
      {categories.map(category => (
        <div key={category._id}>
          <img src={category.image} alt={category.category_name} />
          <span>{category.category_name}</span>
        </div>
      ))}
    </nav>
  );
}

export default CategoryMenu;


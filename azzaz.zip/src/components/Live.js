import React, { useState, useEffect } from 'react';
import axios from 'axios';
import LiveList from './LiveList'; // Asegúrate de tener el componente LiveList creado
import FLVPlayer from './FLVPlayer'; // Asegúrate de tener el componente FLVPlayer creado
import CommentSection from './CommentSection'; // Asegúrate de tener el componente CommentSection creado
import ProductList from './ProductList'; // Asegúrate de tener el componente ProductList creado
import AddProductForm from './AddProductForm'; // Importar el nuevo componente

const LivePage = () => {
  const [selectedLive, setSelectedLive] = useState(null);
  const [liveList, setLiveList] = useState([]);

  useEffect(() => {
    // Obtener la lista de transmisiones en vivo al cargar la página
    const fetchLiveList = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/live');
        setLiveList(response.data);
      } catch (error) {
        console.error('Error al obtener la lista de transmisiones en vivo:', error);
      }
    };

    fetchLiveList();
  }, []); // Se ejecutará solo una vez al cargar la página

  const handleLiveClick = async (liveId) => {
    // Manejar el clic en una transmisión en vivo
    try {
      // Obtener detalles de la transmisión en vivo seleccionada
      const response = await axios.get(`http://localhost:5000/api/live/${liveId}`);
      setSelectedLive(response.data);
    } catch (error) {
      console.error('Error al obtener detalles de la transmisión en vivo:', error);
    }
  };

  const handleProductAdded = (newProduct) => {
    // Actualizar la lista de productos al agregar un nuevo producto
    setSelectedLive((prevSelectedLive) => {
      return {
        ...prevSelectedLive,
        products: [...(prevSelectedLive.products || []), newProduct],
      };
    });
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        {/* Lista de transmisiones en vivo */}
        <LiveList liveList={liveList} onLiveClick={handleLiveClick} />

        {/* Reproductor FLV */}
        {selectedLive && <FLVPlayer liveData={selectedLive} />}
        
        {/* Comentarios, Productos y Formulario para agregar productos */}
        {selectedLive && (
          <div style={{ width: '30%' }}>
            <CommentSection liveId={selectedLive._id} />
            <ProductList vendorId={selectedLive.vendor} products={selectedLive.products} />
            <AddProductForm liveId={selectedLive._id} onProductAdded={handleProductAdded} />
          </div>
        )}
      </div>
    </div>
  );
};

export default LivePage;


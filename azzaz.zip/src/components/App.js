// client/src/components/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Login from './Login';
import Register from './Register';
import Home from './Home';
import Live from './Live'; // Importa el componente Live
import azzaz from './azzaz'; 
import FeaturedProducts from './FeaturedProducts'; 
import CategoryMenu from './CategoryMenu'; 
import { AuthProvider } from './AuthContext';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Switch>
          <Route exact path="/login" component={Login} />
          <Route exact path="/register" component={Register} />
          <Route exact path="/home" component={Home} />
          <Route exact path="/FeaturedProducts" component={FeaturedProducts} />
          <Route exact path="/CategoryMenu" component={CategoryMenu} />
          <Route exact path="/azzaz" component={azzaz} />
          <Route exact path="/live" component={Live} /> {/* Agrega esta línea para la página Live */}
          {/* Otras rutas según tus necesidades */}
        </Switch>
      </Router>
    </AuthProvider>
  );
}

export default App;


import React, { useState } from 'react';
import axios from 'axios';
import './Login.css';
import { useHistory } from 'react-router-dom';

import logo from './logo.png';

function LoginForm({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    try {
      const response = await axios.post('http://localhost:5000/api/auth/login', { email, password });
      
      if (response.data.success) {
        onLogin(response.data.token);
      } else {
        onLogin(null, response.data.message);
      }
    } catch (error) {
      console.error('Error en la autenticación:', error);

      if (error.response && error.response.status === 401) {
        const errorMessage = 'Credenciales incorrectas. ¡Inicio de sesión fallido!';
        console.log('Mensaje de error:', errorMessage);
        onLogin(null, errorMessage);
      } else {
        const errorMessage = 'Error en la autenticación. Verifica tus credenciales.';
        console.log('Mensaje de error:', errorMessage);
        onLogin(null, errorMessage);
      }
    }
  };

  return (
    <div className="login-container">
      <img src={logo} alt="Logo" className="logo" />

      <div className="input-container">
        <label htmlFor="email">Correo electrónico:</label>
        <input
          type="email"
          id="email"
          name="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>
      <div className="input-container">
        <label htmlFor="password">Contraseña:</label>
        <input
          type="password"
          id="password"
          name="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>

      <button className="login-button" onClick={handleLogin}>
        Iniciar sesión
      </button>
    </div>
  );
}

function Login() {
  const history = useHistory();
  const [message, setMessage] = useState(null);

  const handleLogin = (token, errorMessage) => {
    if (token) {
      // Redirigir al usuario a la página de inicio (Home)
      history.push('/home');
    } else {
      setMessage(errorMessage);
    }
  };

  return (
    <div>
      <LoginForm onLogin={handleLogin} />

      {/* Mensaje de éxito o fracaso con estilo dinámico */}
      {message && (
        <div className="message">
          <p className={`error-message ${message.includes('fallido') ? 'error' : 'success'}`}>
            {message}
          </p>
        </div>
      )}

      {/* Footer sin pequeño logo */}
      <div className="footer">
        <p>© 2024 Rez.im, Inc.</p>
      </div>
    </div>
  );
}

export default Login;


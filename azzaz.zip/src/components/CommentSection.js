import React, { useState, useEffect } from 'react';
import axios from 'axios';

const CommentSection = ({ liveId }) => {
  const [comments, setComments] = useState([]);

  useEffect(() => {
    // Función para obtener comentarios desde el backend
    const fetchComments = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/live/${liveId}/comments`);
        setComments(response.data); // Suponiendo que el servidor devuelve los comentarios en el formato correcto
      } catch (error) {
        console.error('Error al obtener comentarios:', error);
      }
    };

    // Llamada a la función para obtener comentarios cuando el componente se monta
    fetchComments();
  }, [liveId]);

  return (
    <div>
      <h3>Comments</h3>
      <ul>
        {comments.map(comment => (
          <li key={comment._id}>
            <strong>{comment.user.profileimg}</strong>: {comment.content}
          </li>
        ))}
      </ul>
      {/* Agregar formulario u otras funcionalidades según sea necesario */}
    </div>
  );
};

export default CommentSection;


import React from 'react';
import './FeaturedProducts.css'; // Importa los estilos


function FeaturedProducts({ products }) {
  const productList = Array.isArray(products) ? products : products?.products;

  if (!Array.isArray(productList)) {
    return <div>Error: Productos destacados no válidos</div>;
  }

  return (
    <div className="grid-container">
      {productList.map(product => (
        <div key={product._id} className="cardComponent">
          <div className="cardDiv">
            {product.images && product.images.length > 0 && (
              <img className="images" src={`http://localhost:5000/images/${product.images[0]}`} alt={product.title} />
            )}
            <h3 className="title">{product.title}</h3>

            <div className="city">{product.city}</div>
            <div className="condition">{product.condition}</div>
            <div className="discount">{product.discount}% </div>

            <div className="finalPrice">${product.finalPrice}</div>
           
            <div className="shippingCost">Costo de envío: ${product.shippingCost}</div>
          </div>
          {/* Si es necesario, puedes agregar más elementos dentro de la tarjeta */}
        </div>
      ))}
    </div>
  );
}

export default FeaturedProducts;


// SearchBar.js
import React from 'react';

function SearchBar() {
  return (
    <div className="search-bar">
      <input type="text" placeholder="Buscar en productos y vendedores" />
      <button>Buscar</button>
    </div>
  );
}

export default SearchBar;


// PrivateRoute.js
import React from 'react';
import { Redirect, Route } from 'react-router-dom';
import { useAuth } from './AuthContext'; // Asegúrate de tener tu propio AuthContext

const PrivateRoute = ({ children, ...rest }) => {
  const { isAuthenticated } = useAuth(); // Ajusta esto según cómo manejes la autenticación

  return (
    <Route
      {...rest}
      render={({ location }) =>
        isAuthenticated ? (
          children
        ) : (
          <Redirect
            to={{
              pathname: '/login',
              state: { from: location },
            }}
          />
        )
      }
    />
  );
};

export default PrivateRoute;


// client/src/components/Home.js
import React from 'react';

function Home() {
  return (
    <div>
      <h1>Home Page</h1>
      
      {/* Contenido de la página principal */}
    </div>
  );
}

export default Home;


import TitleFrame from "./TitleFrame";
import styles from "./Card.module.css";

const Card = () => {
  return (
    <div className={styles.card}>
      <div className={styles.cardChild} />
      <section className={styles.cardFrame}>
        <div className={styles.rectangleVectorParent}>
          <button className={styles.rectangleVector}>
            <img
              className={styles.rectangleVectorChild}
              alt=""
              src="/rectangle-24603.svg"
            />
            <b className={styles.sale}>Sale</b>
          </button>
          <div className={styles.innerFrame}>
            <div className={styles.imagesRectangle}>
              <img
                className={styles.imagesIcon}
                loading="eager"
                alt=""
                src="/images@2x.png"
              />
              <div className={styles.cityFrame} />
            </div>
          </div>
        </div>
        <TitleFrame />
      </section>
      <div className={styles.cityConditionGroup}>
        <div className={styles.conditionFrame}>
          <div className={styles.bra}>{`Brand - `}</div>
          <div className={styles.brandFrame}>
            <div className={styles.brand}>Super Circle</div>
          </div>
        </div>
        <div className={styles.buyNowGroup}>
          <div className={styles.frameContainer}>
            <button className={styles.frameset}>
              <div className={styles.framesetChild} />
              <b className={styles.addToCart}>Add To Cart</b>
            </button>
            <button className={styles.rectangleParent}>
              <div className={styles.frameChild} />
              <b className={styles.buyNow}>Buy Now</b>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Card;

import React from 'react';

const ProductList = ({ vendorId, products }) => {
  return (
    <div>
      <h3>Lista de Productos</h3>
      <ul>
        {products && products.length > 0 ? (
          products.map(product => (
            <li key={product._id}>
              <strong>{product.title}</strong> - ${product.price}
            </li>
          ))
        ) : (
          <p>No hay productos disponibles</p>
        )}
      </ul>
    </div>
  );
};

export default ProductList;

